function mrltv(filename[,nmodes])
%MRLTV      Applies modal analysis and reduction to an LTV file.
%
%   MRLTV(FILENAME[,NMODES]) read an LTV file, applies modal analysis
%   and writes the results to a new LTV file.
%
%   FILENAME should specify the input file name WITHOUT the extension 
%   ".ltv". The output is written to a file FILENAME+"mod.ltv".
%
%   NMODES is an optional input parameter that specifies a reduced 
%   number of states that is stored in the output file. Default is 
%   that all states (according the the input file) are considered.
%
%   See also LTV, SPACNTRL.

% Note that this is only a help message as a MEX function will 
% actually be executed.

% Rev. 21-May-2001 R.Aarts.
